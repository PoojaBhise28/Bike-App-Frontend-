 export default interface BikeModel{

    bikeModel :string;
    price:number;
    color:string
    bikeType:number
    milage:number
    bikeManufracture:string
    description:string
    id:number

 }