 export default interface BikeModel{

    bikeModel :string;
    price:number;
    color:string
    bikeTypeId:number
    milage:number
    bikeManufracture:string
    description:string
    id:number

 }