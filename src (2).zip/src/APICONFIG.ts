export const API_URL = "http://localhost:5255/api";
export const biketypesoptions = [
  
  {
    id: 1,
    type: " Road",
  },
  {
    id: 2,
    type: "Hybrid ",
  },
  {
    id: 3,
    type: "BMX",
  },
  {
  id: 4,
  type: "Mountain",
},
];
