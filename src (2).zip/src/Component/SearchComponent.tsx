import React from 'react'

export default function SearchComponent() {
  return (
    <div>
      SearchComponent
    </div>
  )
}
